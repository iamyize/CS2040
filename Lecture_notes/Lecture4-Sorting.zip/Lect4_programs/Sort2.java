import java.util.*;

public class Sort2 {
	public static void main(String[] args) {
		Arrays.sort(args);
		System.out.println(Arrays.toString(args));
		//System.out.println(args);
	}
}

